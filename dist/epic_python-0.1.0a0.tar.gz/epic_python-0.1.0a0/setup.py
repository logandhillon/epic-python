import setuptools

setuptools.setup(
    name="epic-python",
    version="0.1.0-alpha",
    description="EPIC (Extremely Problematic and Inconventient Code) for Python!",
    packages=["epic-python"]
)